package br.com.fiap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static final int TOTAL_PRODUTOS = 5;
    private static final String ARQUIVO = "lista.json";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Produto> produtos = new ArrayList<>();

        System.out.println("=== Cadastro de produtos de informática ===");
        for (int i = 1; i <= TOTAL_PRODUTOS; i++) {
            System.out.println("\nProduto " + i + " de " + TOTAL_PRODUTOS);
            String nome = lerNome(sc);
            int quantidade = lerInteiro(sc, "Quantidade: ");
            double preco = lerDecimal(sc, "Preço unitário: ");
            produtos.add(new Produto(nome, quantidade, preco));
        }

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileWriter writer = new FileWriter(ARQUIVO)) {
            gson.toJson(produtos, writer);
            System.out.println("\nArquivo " + ARQUIVO + " criado com sucesso!");
        } catch (IOException e) {
            System.out.println("Erro ao salvar o arquivo: " + e.getMessage());
            return;
        }

        ArrayList<Produto> listaLida;
        try (FileReader reader = new FileReader(ARQUIVO)) {
            Type tipoDaLista = new TypeToken<ArrayList<Produto>>() {}.getType();
            listaLida = gson.fromJson(reader, tipoDaLista);
            System.out.println("Lista de produtos recuperada do arquivo:");
            for (Produto p : listaLida) {
                System.out.println(p);
            }
        } catch (IOException e) {
            System.out.println("Erro ao ler o arquivo: " + e.getMessage());
            return;
        }

        System.out.println();
        ProdutoDB db = new ProdutoDB();
        db.InserirProdutosDB(listaLida);
    }

    private static String lerNome(Scanner sc) {
        while (true) {
            System.out.print("Nome: ");
            String nome = sc.nextLine().trim();
            if (!nome.isEmpty()) {
                return nome;
            }
            System.out.println("O nome não pode ser vazio.");
        }
    }

    private static int lerInteiro(Scanner sc, String mensagem) {
        while (true) {
            System.out.print(mensagem);
            try {
                int valor = Integer.parseInt(sc.nextLine().trim());
                if (valor > 0) {
                    return valor;
                }
                System.out.println("Informe um número maior que zero.");
            } catch (NumberFormatException e) {
                System.out.println("Valor inválido. Digite um número inteiro.");
            }
        }
    }

    private static double lerDecimal(Scanner sc, String mensagem) {
        while (true) {
            System.out.print(mensagem);
            try {
                double valor = converterPreco(sc.nextLine());
                if (valor > 0) {
                    return valor;
                }
                System.out.println("Informe um valor maior que zero.");
            } catch (NumberFormatException e) {
                System.out.println("Valor inválido. Exemplos: 21.90, 21,90, 1.500,00 ou 1500");
            }
        }
    }

    private static double converterPreco(String entrada) {
        String txt = entrada.trim().replace("R$", "").replace(" ", "");
        int ultimaVirgula = txt.lastIndexOf(',');
        int ultimoPonto = txt.lastIndexOf('.');

        if (ultimaVirgula >= 0 && ultimoPonto >= 0) {
            if (ultimaVirgula > ultimoPonto) {
                txt = txt.replace(".", "").replace(',', '.');  
            } else {
                txt = txt.replace(",", "");                     
            }
        } else if (ultimaVirgula >= 0 || ultimoPonto >= 0) {
            char sep = ultimaVirgula >= 0 ? ',' : '.';
            int casasDepois = txt.length() - txt.lastIndexOf(sep) - 1;
            if (casasDepois == 3) {
                txt = txt.replace(String.valueOf(sep), "");    
            } else {
                txt = txt.replace(sep, '.');                    
            }
        }
        return Double.parseDouble(txt);
    }
}