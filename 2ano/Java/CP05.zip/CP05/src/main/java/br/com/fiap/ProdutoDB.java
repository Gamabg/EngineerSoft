package br.com.fiap;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class ProdutoDB {

    private static final String URL = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
    private static final String USUARIO = "RM562526";
    private static final String SENHA = "111206";

    public Connection ConexaoDB() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL, USUARIO, SENHA);
            if (conn != null)
                System.out.println("Conexão estabelecida com sucesso!");
            else
                System.out.println("Falha na conexão com o Banco de Dados!");
        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n", e.getSQLState(), e.getMessage());
        }
        return conn;
    }

    /**
     * Grava na tabela TB_PRODUTO apenas o nome do produto e o valor total
     * (quantidade * preço).
     */
    public void InserirProdutosDB(List<Produto> produtos) {
        Connection conn = ConexaoDB();
        if (conn == null) {
            return;
        }

        String sql = "INSERT INTO TB_PRODUTO (NOME, VALOR_TOTAL) VALUES (?, ?)";

        try (conn; PreparedStatement ps = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false);

            for (Produto p : produtos) {
                BigDecimal valorTotal = BigDecimal.valueOf(p.getPreco())
                        .multiply(BigDecimal.valueOf(p.getQuantidade()));

                ps.setString(1, p.getNome());
                ps.setBigDecimal(2, valorTotal);
                ps.addBatch();
            }

            ps.executeBatch();
            conn.commit();
            System.out.println(produtos.size() + " registro(s) incluído(s) com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao gravar no banco: " + e.getMessage());
            try {
                conn.rollback();
            } catch (SQLException ex) {
                // conexão já pode estar fechada
            }
        }
    }
}
